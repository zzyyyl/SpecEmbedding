SpecialToken = {
    "PAD": 0,
}